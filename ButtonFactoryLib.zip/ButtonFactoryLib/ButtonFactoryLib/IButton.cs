﻿
using System;

namespace ButtonFactoryLib
{
    /// <summary>
    /// Інтерфейс кнопки — продукт фабрики
    /// </summary>
    public interface IButton
    {
        void Draw();
        void Press();
    }
}
