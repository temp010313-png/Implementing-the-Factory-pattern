﻿using System;

namespace ButtonFactoryLib
{
    // iOS concrete buttons
    public class IOSLikeButton : IButton
    {
        public void Draw() => Console.WriteLine("[iOS] Draw: Like Button");
        public void Press() => Console.WriteLine("[iOS] Action: Liked!");
    }

    public class IOSShareButton : IButton
    {
        public void Draw() => Console.WriteLine("[iOS] Draw: Share Button");
        public void Press() => Console.WriteLine("[iOS] Action: Shared to story...");
    }

    public class IOSFollowButton : IButton
    {
        public void Draw() => Console.WriteLine("[iOS] Draw: Follow Button");
        public void Press() => Console.WriteLine("[iOS] Action: Now following user...");
    }

    public class IOSDialog : Dialog
    {
        public override IButton CreateButton(ButtonType type)
        {
            switch (type)
            {
                case ButtonType.First:
                    return new IOSLikeButton();
                case ButtonType.Second:
                    return new IOSShareButton();
                case ButtonType.Third:
                    return new IOSFollowButton();
                default:
                    return null;
            }
        }
    }
}
