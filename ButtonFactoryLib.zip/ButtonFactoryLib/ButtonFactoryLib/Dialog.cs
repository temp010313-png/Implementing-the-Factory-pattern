﻿namespace ButtonFactoryLib
{
    /// <summary>
    /// Абстрактна фабрика — визначає фабричний метод
    /// </summary>
    public abstract class Dialog
    {
        /// <summary>
        /// Фабричний метод — повинен створювати конкретний IButton
        /// </summary>
        /// <param name="type">тип кнопки в межах сімейства</param>
        /// <returns>IButton</returns>
        public abstract IButton CreateButton(ButtonType type);

        /// <summary>
        /// Утилітний метод для демонстрації: відмалювати та натиснути кнопку
        /// </summary>
        public void ShowButton(ButtonType type)
        {
            var btn = CreateButton(type);
            if (btn == null) return;
            btn.Draw();
            btn.Press();
        }
    }
}
