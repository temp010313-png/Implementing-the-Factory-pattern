﻿namespace ButtonFactoryLib
{
    /// <summary>
    /// Типи кнопок, які може створювати фабрика
    /// </summary>
    public enum ButtonType
    {
        First = 1,
        Second = 2,
        Third = 3
    }
}
