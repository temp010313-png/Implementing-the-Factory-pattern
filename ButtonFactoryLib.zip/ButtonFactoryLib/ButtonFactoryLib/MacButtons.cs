﻿using System;

namespace ButtonFactoryLib
{
    // Mac concrete buttons
    public class MacRecordButton : IButton
    {
        public void Draw() => Console.WriteLine("[MacOS] Draw: Record Button");
        public void Press() => Console.WriteLine("[MacOS] Action: Recording started...");
    }

    public class MacEditButton : IButton
    {
        public void Draw() => Console.WriteLine("[MacOS] Draw: Edit Button");
        public void Press() => Console.WriteLine("[MacOS] Action: Open editor...");
    }

    public class MacExportButton : IButton
    {
        public void Draw() => Console.WriteLine("[MacOS] Draw: Export Button");
        public void Press() => Console.WriteLine("[MacOS] Action: Exporting project...");
    }

    public class MacDialog : Dialog
    {
        public override IButton CreateButton(ButtonType type)
        {
            switch (type)
            {
                case ButtonType.First:
                    return new MacRecordButton();
                case ButtonType.Second:
                    return new MacEditButton();
                case ButtonType.Third:
                    return new MacExportButton();
                default:
                    return null;
            }
        }
    }
}
