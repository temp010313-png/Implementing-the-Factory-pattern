﻿using System;

namespace ButtonFactoryLib
{
    // Windows concrete buttons
    public class WinRestartButton : IButton
    {
        public void Draw() => Console.WriteLine("[Windows] Draw: Restart Button");
        public void Press() => Console.WriteLine("[Windows] Action: System restarting...");
    }

    public class WinSleepButton : IButton
    {
        public void Draw() => Console.WriteLine("[Windows] Draw: Sleep Button");
        public void Press() => Console.WriteLine("[Windows] Action: Entering sleep mode...");
    }

    public class WinShutdownButton : IButton
    {
        public void Draw() => Console.WriteLine("[Windows] Draw: Shutdown Button");
        public void Press() => Console.WriteLine("[Windows] Action: Shutting down...");
    }

    public class WindowsDialog : Dialog
    {
        public override IButton CreateButton(ButtonType type)
        {
            switch (type)
            {
                case ButtonType.First:
                    return new WinRestartButton();
                case ButtonType.Second:
                    return new WinSleepButton();
                case ButtonType.Third:
                    return new WinShutdownButton();
                default:
                    return null;
            }
        }
    }
}
