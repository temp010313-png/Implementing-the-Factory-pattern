﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ButtonFactoryLib;

namespace TestProgram
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dialog dialog;

            Console.WriteLine("=== Windows ===");
            dialog = new WindowsDialog();
            dialog.ShowButton(ButtonType.First);
            dialog.ShowButton(ButtonType.Second);
            dialog.ShowButton(ButtonType.Third);

            Console.WriteLine("\n=== MacOS ===");
            dialog = new MacDialog();
            dialog.ShowButton(ButtonType.First);
            dialog.ShowButton(ButtonType.Second);
            dialog.ShowButton(ButtonType.Third);

            Console.WriteLine("\n=== iOS ===");
            dialog = new IOSDialog();
            dialog.ShowButton(ButtonType.First);
            dialog.ShowButton(ButtonType.Second);
            dialog.ShowButton(ButtonType.Third);

            Console.WriteLine("\nDone. Press any key...");
            Console.ReadKey();
        }
    }
}
